Some basic python scripts which use the REST interface:

zkrest.py -- basic REST ZooKeeper client
demo_master_election.py -- shows how to implement master election
demo_queue.py -- basic queue
zk_dump_tree.py -- dumps the nodes & data of a znode hierarchy

Generally these scripts require:
  * simplejson
